import sys
import numpy as np
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import time
import cv2
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import String, Int32MultiArray, Int32, Bool, Float32MultiArray
from cv_bridge import CvBridge, CvBridgeError
x, y, t = None, None, None
# setup move group
arm_group = moveit_commander.MoveGroupCommander("tmr_arm")
PI = np.pi

def pose():
    wpose = arm_group.get_current_pose().pose
    print("x = " + str(wpose.position.x) + "\ny = " + str(wpose.position.y) + "\nz = " + str(wpose.position.z))
    return [wpose.position.x, wpose.position.y, wpose.position.z]
    """print(wpose)
    for i in wpose:
        print(i)"""

if __name__ == '__main__':
    rospy.init_node("pose")
    point = pose()
    

    # joint_goal = arm_group.get_current_joint_values()
    # print(joint_goal)
    # # f = open("default_position.txt", "a")
    # # for i in range(6):
    # #     f.write(str(joint_goal[i])+"\t")
    # # f.write("\n")
    # # f.close()
    # time.sleep(1)

    #####################
    # pose: 
    #     position: 
    #         x: 0.6399530144824053
    #         y: 0.24848366716300951
    #         z: 0.1743537162538541
    #     orientation: 
    #         x: 0.6395335027499236
    #         y: 0.7683885123330814
    #         z: 0.014281248435642862
    #         w: 0.01928831040000542
    # joints:
    #        [0.5540836477012997, 0.5453556032817557, 1.6149217102642015, -0.6288130131533591, 1.543268695345347, 0.37100853343689666]