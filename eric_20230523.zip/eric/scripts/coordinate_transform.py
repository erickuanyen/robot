import rospy
import math
import matplotlib.pyplot as plt
import numpy as np
from std_msgs.msg import String, Float32MultiArray

x,y,z,t = None, None, None, None

def matrix_callback(data):
    global x,y,z,t
    matrix_data = np.array(data.data)
    print("Received matrix:\n", matrix_data)
    x, y, z, t = matrix_data[0], matrix_data[1], matrix_data[2], matrix_data[3]

def main():
    global x,y,z,t
    rospy.init_node('transform', anonymous=True)
    rospy.Subscriber("cam_to_puck", Float32MultiArray, matrix_callback)
    #theta = rospy.get_param("tilted_angle")
    #base to cam
    offset_x = 0.65
    offset_y = 0
    offset_z = 0.687

    T_base_to_cam = np.array([  [1, 0, 0, offset_x], 
                                [0, 1, 0, offset_y],
                                [0, 0, 1, offset_z],
                                [0, 0, 0, 1]])
    R_base_to_cam = np.array([  [1, 0, 0, 0], 
                              [0,-1, 0, 0],
                              [0, 0,-1, 0],
                              [0, 0, 0, 1]])
    # cos_theta = np.cos(theta)
    # sin_theta = np.sin(theta)
    # T_correct_tilt = np.array([ [cos_theta, -sin_theta, 0, 0],
    #                             [sin_theta, cos_theta , 0, 0],
    #                             [0        , 0         , 1, 0], 
    #                             [0        , 0         , 0, 1]])
    T_cam_to_puck = np.array([  [1, 0, 0, x], 
                                [0, 1, 0, y],
                                [0, 0, 1, z],
                                [0, 0, 0, 1]])
    T_base_to_cam_inv = np.linalg.inv(T_base_to_cam)
    R_base_to_cam_inv = np.linalg.inv(R_base_to_cam)
    #T_correct_tilt_inv = np.linalg.inv(T_correct_tilt)

    T_base_to_puck = T_base_to_cam_inv.dot(R_base_to_cam_inv).dot(T_cam_to_puck)
    #dot(T_correct_tilt_inv)
    print(T_base_to_puck)
    puck = [T_base_to_puck[0][3], T_base_to_puck[1][3], t]
    pub = rospy.Publisher("base_to_puck", Float32MultiArray, queue_size=10)
    puck_array = Float32MultiArray(data=puck)
    puck.publish(puck_array)  
    

if __name__ == '__main__':
    main()
    rospy.spin()

