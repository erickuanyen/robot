import rospy
import math
import matplotlib.pyplot as plt
import numpy as np
import cv2
import time
import csv
from std_msgs.msg import Float32MultiArray

x, vx, ax, y, vy, ay, t, vt, at, matrix_data = [], [], [], [], [], [], [], [], [], []

# def save_csv():
#     global t, x, y
#     data = list(zip(t, x, y))
#     print(data)
#     output_file = r"C:\Users\EricLin\Desktop\B3-2\Independent Study (2)\Code\eric\scripts\output.csv"
#     with open(output_file, "w", newline="") as csvfile:
#         writer = csv.writer(csvfile)
#         writer.writerow(["t", "x", "y"])  # Write header
#         writer.writerows(data)  # Write data rows

def transform():
    global x, vx, ax, y, vy, ay, t, vt, at, matrix_data

    # Base to cam
    offset_x = 0.65
    offset_y = 0
    offset_z = 0.687

    T_base_to_cam = np.array([[1, 0, 0, offset_x], 
                              [0, 1, 0, offset_y],
                              [0, 0, 1, offset_z],
                              [0, 0, 0, 1]])
    R_base_to_cam = np.array([[1, 0, 0, 0], 
                              [0, -1, 0, 0],
                              [0, 0, -1, 0],
                              [0, 0, 0, 1]])

    T_cam_to_puck = np.array([[1, 0, 0, matrix_data[0]], 
                              [0, 1, 0, matrix_data[1]],
                              [0, 0, 1, matrix_data[2]],
                              [0, 0, 0, 1]])

    T_base_to_cam_inv = np.linalg.inv(T_base_to_cam)
    R_base_to_cam_inv = np.linalg.inv(R_base_to_cam)

    result = np.matmul(T_base_to_cam_inv, T_cam_to_puck)
    T_base_to_puck = np.matmul(R_base_to_cam_inv, result)

    x.append(-T_base_to_puck[0][3])
    y.append(T_base_to_puck[1][3])
    t.append(matrix_data[3])

    # Publish the T_base_to_puck values
    pub.publish(Float32MultiArray(data=np.array([x,y])))

def matrix_callback(data):
    global matrix_data
    matrix_data = np.array(data.data)
    #print("Received matrix:\n", matrix_data)
    transform()


def read_data_file(file_path):
    table = []
    with open(file_path, 'r') as file:
        lines = file.readlines()

        for line in lines[1:]:
            row = line.strip().split('\t')
            row = [float(element) for element in row] 
            table.append(row)

    return table

def plot():
    global x, vx, ax, y, vy, ay, t, vt, at
    for i in range(len(t)-1):
        vt.append((t[i+1]+t[i])/2)
        vx.append((x[i+1]-x[i])/(t[i+1]-t[i]))
        vy.append((y[i+1]-y[i])/(t[i+1]-t[i]))
    
    plt.figure(1)
    plt.scatter(x, y)
    plt.title('trajectory')
    plt.xlabel('X Axis')
    plt.ylabel('Y Axis')

    plt.figure(2)
    plt.plot(t, x)
    plt.title('X-t')
    plt.xlabel('time')
    plt.ylabel('X')

    plt.figure(3)
    plt.plot(t, y)
    plt.title('Y-t')
    plt.xlabel('time')
    plt.ylabel('Y')

    plt.figure(4)
    plt.plot(vt, vx)
    plt.title('Vx-t')
    plt.xlabel('time')
    plt.ylabel('Vx')

    plt.figure(5)
    plt.plot(vt, vy)
    plt.title('Vy-t')
    plt.xlabel('time')
    plt.ylabel('Vy')

    plt.show()


if __name__ == '__main__':
    rospy.init_node('transform_and_plot', anonymous=True)
    pub = rospy.Publisher("base_to_puck", Float32MultiArray, queue_size=10)
    
    while not rospy.is_shutdown():
        if matrix_data and matrix_data[3] <= totaltime:
            rospy.Subscriber("cam_to_puck", Float32MultiArray, matrix_callback)
            rospy.spin()
        # else:
        #     plot()
        #     save_csv()



# file_path = r'C:\Users\EricLin\Desktop\B3-2\Independent Study (2)\Code\eric\scripts\read_pointcloud.txt'  # Replace with the actual file path
# matrix_data = read_data_file(file_path)
# for i in range(len(matrix_data)-1):
#     #print(matrix_data[i+1])
#     transform(matrix_data[i+1])
# save_csv()
# plot()

