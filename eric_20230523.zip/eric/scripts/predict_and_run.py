import rospy
import matplotlib
import sys
import numpy as np
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import time
import cv2
import time
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import String, Int32MultiArray, Int32, Bool, Float32MultiArray

arm_group = moveit_commander.MoveGroupCommander("tmr_arm")
PI = np.pi

def get_plane_param():
    with open(f"plane.txt", 'r') as f:
        line = f.readline()
        # Split the line into individual numbers
        numbers = line.split()
        
        # Convert the numbers to floats
        numbers = [float(num) for num in numbers]
        # Check if there are exactly three numbers
        if len(numbers) != 3:
            raise ValueError("The file should contain exactly three numbers.")
        return numbers

def joint_goal_plan_exec(joint_deg):
    joint_goal = arm_group.get_current_joint_values()
    joint_goal[0] = joint_deg[0] *PI/180
    joint_goal[1] = joint_deg[1] *PI/180
    joint_goal[2] = joint_deg[2] *PI/180
    joint_goal[3] = joint_deg[3] *PI/180
    joint_goal[4] = joint_deg[4] *PI/180
    joint_goal[5] = joint_deg[5] *PI/180

    arm_group.go(joint_goal, wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def joint_goal_plan_exec_rad(rad):
    joint_goal = arm_group.get_current_joint_values()
    joint_goal[0] = rad[0]
    joint_goal[1] = rad[1]
    joint_goal[2] = rad[2]
    joint_goal[3] = rad[3]
    joint_goal[4] = rad[4]
    joint_goal[5] = rad[5]

    arm_group.go(joint_goal, wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def pose_goal_plan_exec(trans, q):
    pose_goal = geometry_msgs.msg.Pose()
    pose_goal.position.x = trans[0]
    pose_goal.position.y = trans[1]
    pose_goal.position.z = trans[2]
    pose_goal.orientation.x = q[0]
    pose_goal.orientation.y = q[1]
    pose_goal.orientation.z = q[2]
    pose_goal.orientation.w = q[3]
    arm_group.set_pose_target(pose_goal)
    plan = arm_group.go(wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def cartesian_plan_exec(position):
    waypoints = []
    wpose = arm_group.get_current_pose().pose
    print(wpose)
    wpose.position.x =  position[0]
    wpose.position.y =  position[1]
    wpose.position.z =  position[2]
    waypoints.append(copy.deepcopy(wpose))
    (plan, fraction) = arm_group.compute_cartesian_path(
        waypoints, 0.2, 0.0  # waypoints to follow  # eef_step # jump_threshold
    )  
    arm_group.execute(plan, wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def direction(vector, vector_prime):
    if vector_prime == np.array([np.nan,np.nan]):
        return np.array([0,0])
    else:
        return vector_prime - vector

def normalize(v):
    norm = np.linalg.norm(v)
    if norm == 0:
        raise ValueError("Input vector has zero length.")
    return v / norm

def callback(data):
    global loc_puck, loc_goal, loc_puck_prime
    #rospy.loginfo(rospy.get_caller_id() + "I heard %s", data.data)
    loc_puck[0] = data.data[0]
    loc_puck[1] = data.data[1]
    
plane_param = get_plane_param()

r = 0.02+0.025
b = 0.6


loc_goal = np.array([np.nan,np.nan])
loc_puck = np.array([np.nan,np.nan])
loc_puck_prime = np.array([np.nan,np.nan])
vel_puck = np.array([np.nan,np.nan])
#cartesian_plan_exec(destination)
sampletime = rospy.get_param("sampletime")
totaltime = rospy.get_param("totaltime")

while((not rospy.is_shutdown())):
    if __name__ == '__main__':
        rospy.init_node('motion_decider', anonymous=True)
        loc_puck_prime = loc_puck
        rospy.Subscriber("base_to_puck", String, callback)
        D_incident = direction(loc_puck, loc_puck_prime)
        D_relfection = direction(loc_puck+D_incident*b, loc_goal)
        rospy.spin()