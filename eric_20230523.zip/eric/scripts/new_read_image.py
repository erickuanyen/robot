import cv2
import time
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import String, Int32MultiArray, Int32, Float32 , Bool, Float32MultiArray
from cv_bridge import CvBridge, CvBridgeError
import rospy
import numpy as np
#set parameters:
minRad = 10
maxRad = 30
#Move this to control end time and sample time
sampletime = 0.01
totaltime = 60
recordtime = 15
elapsedtime = 0
datapts = 0
sampleend = False
x_sum,y_sum,r_sum,x_avg,y_avg,r_avg = 0,0,0,0,0,0
rospy.set_param("sampletime", sampletime)
rospy.set_param("totaltime", totaltime)

def mask(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    lower_red = np.array([0 , 80 ,40])
    upper_red = np.array([25 , 255 ,255])
    red_mask = cv2.inRange(hsv, lower_red, upper_red)
    lower_red = np.array([155 , 80 ,40])
    upper_red = np.array([180 , 255 ,255])
    red_mask_2 = cv2.inRange(hsv, lower_red, upper_red)
    red_mask = cv2.bitwise_or(red_mask,red_mask_2)
    return red_mask

def find_tilt(img):
    # Convert the image to grayscale
    red_mask = mask(img)
    # Apply edge detection using Canny
    edges = cv2.Canny(red_mask, 50, 150)

    # Find the contours of the line
    contours, hierarchy = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    param = []  # m, b, t

    # Approximate the contours and get the length of the line
    for i in range(len(contours)):
        arc_length = cv2.arcLength(contours[i], True)
        approx = cv2.approxPolyDP(contours[i], 0.02 * arc_length, True)
        thickness = approx.shape[0]

        # Find the left and rightmost points of the line
        ptx, pty = [], []
        for j in range(len(contours[i])):
            ptx.append(contours[i][j][0][0])
            pty.append(contours[i][j][0][1])
        x_left, x_right = min(ptx), max(ptx)
        y_left, y_right = contours[i][ptx.index(x_left)][0][1], contours[i][ptx.index(x_right)][0][1]

        # Print the equation of the line
        m = (y_right - y_left) / (x_right - x_left)
        b = y_left - m * x_left
        param.append([m, b, thickness])
        #print(m, b, thickness)
        # Draw the detected line
        cv2.line(img, (x_left, y_left), (x_right, y_right), (0, 0, 255), thickness)
        # cv2.putText(
        #     img,
        #     f"y={m:.2f}x+{b:.2f}",
        #     (x_left, y1),
        #     cv2.FONT_HERSHEY_SIMPLEX,
        #     0.5,
        #     (0, 150, 0),
        #     1,
        #     cv2.LINE_AA,
        # )
        # Print the equation and thickness of the line
        # print(f"y = {m:.2f}x + {b:.2f}, thickness = {thickness}")

    # Find the line with maximum thickness
    thickest_line = max(param, key=lambda x: x[2])

    # Calculate the tilt angle
    angle_rad = np.arctan(thickest_line[0])  # Angle in radians
    angle_deg = np.degrees(angle_rad)  # Angle in degrees

    # Determine the tilt direction
    tilt_direction = "Clockwise" if thickest_line[0] > 0 else "Anti-clockwise"

    # Print the angle and tilt direction
    #print(f"Tilt angle: {angle_deg:.2f} degrees {tilt_direction}")

    # Print the thickest line information
    #print(f"Thickest line: y = {thickest_line[0]:.2f}x + {thickest_line[1]:.2f}, thickness ={thickest_line[2]:.2f}")

    cv2.imshow("Detected lines", red_mask)
    
    return angle_deg

def record_positon_pixel(puck):
    global elapsedtime, recordtime, f, datapts, sampleend ,x_sum,y_sum,r_sum,x_avg,y_avg,r_avg 
    
    if(elapsedtime < recordtime):
        f.write(str(datapts+1)+"\t"+str(elapsedtime)+"\t")
        for j in range(3):
            f.write(str(puck[j])+"\t")
        x_sum +=puck[0]
        y_sum +=puck[1]
        r_sum +=puck[2]
        f.write("\n")
        datapts += 1
        #print(x_sum, y_sum, r_sum)
    else:
        if(sampleend == False):
            x_avg = round(x_sum/datapts)
            y_avg = round(y_sum/datapts)
            r_avg = round(r_sum/datapts)
            f.write("Average\tN/A\t"+str(x_avg)+"\t"+str(y_avg)+"\t"+str(r_avg))
            sampleend = True
        else:
            f.close()

def find_ball_center(img):
    global minRad, maxRad
    red_mask = mask(img)
    #cv2.imshow("red_mask", red_mask)
    #cv2.imwrite('red_mask.png',red_mask)
    gray_blurred = cv2.blur(red_mask, (3, 3))
    detected_circles = cv2.HoughCircles(gray_blurred, cv2.HOUGH_GRADIENT, 1, 200, param1 = 70,
                param2 = 25, minRadius = minRad, maxRadius = maxRad)
    red_mask = cv2.cvtColor(red_mask, cv2.COLOR_GRAY2BGR)
    if detected_circles is not None:
        detected_circles = np.uint16(np.around(detected_circles))    
        for pt in detected_circles[0, :]:
            a, b, r = pt[0], pt[1], pt[2]
            cv2.circle(red_mask, (a, b), r, (0, 255, 0), 2)
            cv2.circle(red_mask, (a, b), 1, (0, 0, 255), 3)
        circle = cv2.imshow("circle", red_mask)
        #cv2.imwrite("circle.png",circle)
        #print("detected_circles = ", detected_circles)
        detected_circles = [int(detected_circles[0][0][0]), int(detected_circles[0][0][1]), int(detected_circles[0][0][2])]
    return detected_circles
#size of detected_circles is [# of pucks][3] (a,b,r)

class observer_reading:
    def __init__(self) -> None:
        self.initial_node = rospy.init_node('Observer_Reading_Node',anonymous=True)
        self.cv_bridge = CvBridge()
        self.image_sub = rospy.Subscriber("/camera/color/image_raw",Image,self.image_callback,queue_size=1)
        pass
  
    ## Method 1, use callback function
    def image_callback(self, data):
        # print(data.header)
        color_image = self.cv_bridge.imgmsg_to_cv2(data,desired_encoding="passthrough")
        cv2.cvtColor(color_image, cv2.COLOR_BGR2RGB,color_image)
        cv2.imshow("frame",color_image)
        cv2.imwrite('original_image.png',color_image)
        cv2.waitKey(1)

    ##  Method 2, Read Topic Once
    def read_image(self):
        ros_image = rospy.wait_for_message("/camera/color/image_raw",Image,rospy.Duration(0.3))
        if(ros_image):
            # print(ros_image.header.stamp)
            ##  convert ROS image message sensor_msgs::Image to OpenCV based Format
            ##  API used: CvBridge
            color_image = self.cv_bridge.imgmsg_to_cv2(ros_image,desired_encoding="passthrough")
            cvt_img = cv2.cvtColor(color_image, cv2.COLOR_BGR2RGB,color_image)
            #cv2.imshow("original_image",cvt_img)
            cv2.waitKey(1)
            return cvt_img
        # pass
OR = observer_reading()
f = open("read_image.txt", "w")
f.write("datapts\ttime\tpixel_x\tpixel_y\tpixel_rad\n")
puck_loc = rospy.Publisher('PuckPixel', Float32MultiArray, queue_size=10)
#tilt = rospy.Publisher('tilted_angle', Float32, queue_size=10)
rate = rospy.Rate(round(1/sampletime))
while((not rospy.is_shutdown()) and elapsedtime <= totaltime):
    img_data = OR.read_image()
    #tilted_angle = find_tilt(img_data)
    puck = find_ball_center(img_data)
    if(puck!=None):
        puck.append(elapsedtime)
        #print(puck)
        puck_array = Float32MultiArray(data=puck)
        #tilt = Float32(data=tilted_angle)
        puck_loc.publish(puck_array)  
        #tilt.publish(tilted_angle)
        rospy.set_param("PuckPixel", puck)
        record_positon_pixel(puck)
    elapsedtime += sampletime
    elapsedtime = round(elapsedtime,2)
    #print(elapsedtime)
    rate.sleep()