import cv2
import time
from std_msgs.msg import String, Int32MultiArray, Int32, Bool, Float32MultiArray
import rospy
import numpy as np
import matplotlib.pyplot as plt
import csv

x, vx, ax, y, vy, ay, t, vt, at = [], [], [], [], [], [], [], [], []
reception = []
sampletime = rospy.get_param("sampletime")
totaltime = rospy.get_param("totaltime")
elapsedtime = 0

def callback(data):
    global x, y, t, reception
    reception = data
    x.append(reception.data[0])
    y.append(reception.data[1])
    t.append(reception.data[2])

def listener():
    global x, y, t, reception
    rospy.init_node('Plotting', anonymous=True)
    rospy.Subscriber("base_to_puck", Float32MultiArray, callback)
    while not rospy.is_shutdown() and reception[2] <= totaltime:
        rospy.spin()

listener()

# t = np.arange(0, 20.05, 0.05)
# x = np.sin(t)
# y = np.cos(t)


for i in range(len(t)-1):
    vt.append((t[i+1]+t[i])/2)
    vx.append((x[i+1]-x[i])/(t[i+1]-t[i]))
    vy.append((y[i+1]-y[i])/(t[i+1]-t[i]))
    
for j in range(len(vt)-1):
    at.append((vt[j+1]+vt[j])/2)
    ax.append((vx[j+1]-vx[j])/(vt[j+1]-vt[j]))
    ay.append((vy[j+1]-vy[j])/(vt[j+1]-vt[j]))

plt.figure(1)
plt.scatter(x, y, s=1, c='red')
plt.title('trajectory')
plt.xlabel('X Axis')
plt.ylabel('Y Axis')

plt.figure(2)
plt.plot(t, x)
plt.title('X-t')
plt.xlabel('time')
plt.ylabel('X')

plt.figure(3)
plt.plot(t, y)
plt.title('Y-t')
plt.xlabel('time')
plt.ylabel('Y')

plt.figure(4)
plt.plot(vt, vx)
plt.title('Vx-t')
plt.xlabel('time')
plt.ylabel('Vx')

plt.figure(5)
plt.plot(vt, vy)
plt.title('Vy-t')
plt.xlabel('time')
plt.ylabel('Vy')

plt.figure(6)
plt.plot(at, ax)
plt.title('Ax-t')
plt.xlabel('time')
plt.ylabel('Ax')

plt.figure(7)
plt.plot(at, ay)
plt.title('Ay-t')
plt.xlabel('time')
plt.ylabel('Ay')

plt.show()

# Writing to CSV file
header = ['t', 'x', 'y', 'vx', 'vy', 'ax', 'ay']
rows = zip(t, x, y, vx, vy, ax, ay)

with open('output.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(header)
    writer.writerows(rows)
