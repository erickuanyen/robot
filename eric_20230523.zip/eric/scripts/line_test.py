import os
import cv2
import numpy as np
import rospy
def find_tilt(img):
    # Convert the image to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Apply edge detection using Canny
    edges = cv2.Canny(gray, 50, 150)

    # Find the contours of the line
    contours, hierarchy = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    param = []  # m, b, t

    # Approximate the contours and get the length of the line
    for i in range(len(contours)):
        arc_length = cv2.arcLength(contours[i], True)
        approx = cv2.approxPolyDP(contours[i], 0.02 * arc_length, True)
        thickness = approx.shape[0]

        # Find the left and rightmost points of the line
        ptx, pty = [], []
        for j in range(len(contours[i])):
            ptx.append(contours[i][j][0][0])
            pty.append(contours[i][j][0][1])
        x_left, x_right = min(ptx), max(ptx)
        y_left, y_right = contours[i][ptx.index(x_left)][0][1], contours[i][ptx.index(x_right)][0][1]

        # Print the equation of the line
        m = (y_right - y_left) / (x_right - x_left)
        b = y_left - m * x_left
        param.append([m, b, thickness])

        # Draw the detected line
        y1 = int(m * x_left + (y_left - m * x_left))
        y2 = int(m * x_right + (y_left - m * x_left))
        cv2.line(img, (x_left, y1), (x_right, y2), (0, 0, 255), thickness)
        cv2.putText(
            img,
            f"y={m:.2f}x+{b:.2f}",
            (x_left, y1),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (0, 150, 0),
            1,
            cv2.LINE_AA,
        )

        # Print the equation and thickness of the line
        print(f"y = {m:.2f}x + {b:.2f}, thickness = {thickness}")

    # Find the line with maximum thickness
    thickest_line = max(param, key=lambda x: x[2])

    # Calculate the tilt angle
    angle_rad = np.arctan(thickest_line[0])  # Angle in radians
    angle_deg = np.degrees(angle_rad)  # Angle in degrees

    # Determine the tilt direction
    tilt_direction = "Clockwise" if thickest_line[0] > 0 else "Anti-clockwise"

    # Print the angle and tilt direction
    print(f"Tilt angle: {angle_deg:.2f} degrees {tilt_direction}")

    # Print the thickest line information
    print(f"Thickest line: y = {thickest_line[0]:.2f}x + {thickest_line[1]:.2f}, thickness ={thickest_line[2]:.2f}")

    cv2.imshow("Detected lines", img)
    
    return angle_deg

# Load the image
img = cv2.imread(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'line_test.png'))
tilted_angle = find_tilt(img)

