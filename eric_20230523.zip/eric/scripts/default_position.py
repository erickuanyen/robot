import sys
import numpy as np
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import time
import cv2
import time
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import String, Int32MultiArray, Int32, Bool, Float32MultiArray
# setup move group
arm_group = moveit_commander.MoveGroupCommander("tmr_arm")
PI = np.pi

def joint_goal_plan_exec(joint_deg):
    joint_goal = arm_group.get_current_joint_values()
    joint_goal[0] = joint_deg[0] *PI/180
    joint_goal[1] = joint_deg[1] *PI/180
    joint_goal[2] = joint_deg[2] *PI/180
    joint_goal[3] = joint_deg[3] *PI/180
    joint_goal[4] = joint_deg[4] *PI/180
    joint_goal[5] = joint_deg[5] *PI/180

    arm_group.go(joint_goal, wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def joint_goal_plan_exec_rad(rad):
    joint_goal = arm_group.get_current_joint_values()
    joint_goal[0] = rad[0]
    joint_goal[1] = rad[1]
    joint_goal[2] = rad[2]
    joint_goal[3] = rad[3]
    joint_goal[4] = rad[4]
    joint_goal[5] = rad[5]

    arm_group.go(joint_goal, wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def pose_goal_plan_exec(trans, q):
    pose_goal = geometry_msgs.msg.Pose()
    pose_goal.position.x = trans[0]
    pose_goal.position.y = trans[1]
    pose_goal.position.z = trans[2]
    pose_goal.orientation.x = q[0]
    pose_goal.orientation.y = q[1]
    pose_goal.orientation.z = q[2]
    pose_goal.orientation.w = q[3]
    arm_group.set_pose_target(pose_goal)
    plan = arm_group.go(wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def cartesian_plan_exec(position):
    waypoints = []
    wpose = arm_group.get_current_pose().pose
    print(wpose)
    wpose.position.x =  position[0]
    wpose.position.y =  position[1]
    wpose.position.z =  position[2]
    waypoints.append(copy.deepcopy(wpose))
    (plan, fraction) = arm_group.compute_cartesian_path(
        waypoints, 0.2, 0.0  # waypoints to follow  # eef_step # jump_threshold
    )  
    arm_group.execute(plan, wait=True)
    arm_group.stop()
    arm_group.clear_pose_targets()

def get_plane_param():
    with open(f"plane.txt", 'r') as f:
        line = f.readline()
        # Split the line into individual numbers
        numbers = line.split()
        
        # Convert the numbers to floats
        numbers = [float(num) for num in numbers]
        # Check if there are exactly three numbers
        if len(numbers) != 3:
            raise ValueError("The file should contain exactly three numbers.")
        
        return numbers

if __name__ == '__main__':
    rospy.init_node("demo")
    print("go to inital")
    # Step1: go initail pose
    #joints = [0.5540836477012997, 0.5453556032817557, 1.6149217102642015, -0.6288130131533591, 1.543268695345347, 0.37100853343689666]
    plane_param = get_plane_param()
    print(plane_param)
    x = 0.6399530144824053
    y = 0.24848366716300951
    z = x*plane_param[0] + y*plane_param[1] + plane_param[2]
    trans = [x, y, z]
    q = [0.6395335027499236,0.7683885123330814,0.0,0.0]
    print(trans)
    #joint_goal_plan_exec_rad(joints)
    pose_goal_plan_exec(trans, q)

    
    # position: 
    #         x: 0.6399530144824053
    #         y: 0.24848366716300951
    #         z: 0.1743537162538541
    
    #input("Going to move, press enter to continue")
    # MOTION Y -    
    #
    #listener()
    #destination = [0.64, -0.1, 0.177]
    
    #cartesian_plan_exec(destination)

    # joint_goal = arm_group.get_current_joint_values()
    # print(joint_goal)
    # # f = open("default_position.txt", "a")
    # # for i in range(6):
    # #     f.write(str(joint_goal[i])+"\t")
    # # f.write("\n")
    # # f.close()
    # time.sleep(1)

    #####################
    # pose: 
    #     position: 
    #         x: 0.6399530144824053
    #         y: 0.24848366716300951
    #         z: 0.1743537162538541
    #     orientation: 
    #         x: 0.6395335027499236
    #         y: 0.7683885123330814
    #         z: 0.014281248435642862
    #         w: 0.01928831040000542
    # joints:
    #        [0.5540836477012997, 0.5453556032817557, 1.6149217102642015, -0.6288130131533591, 1.543268695345347, 0.37100853343689666]