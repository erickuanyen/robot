import numpy as np

def fit_plane_least_squares(points):
    # Convert the list of points to a numpy array
    points = np.array(points)
    
    # Extract the x, y, and z coordinates from the points
    x = points[:, 0]
    y = points[:, 1]
    z = points[:, 2]
    
    # Create the A matrix for the least squares method
    A = np.column_stack((x, y, np.ones_like(x)))
    
    # Calculate the coefficients using the least squares method
    coeffs, _, _, _ = np.linalg.lstsq(A, z, rcond=None)
    
    # Extract the plane parameters
    a, b, c = coeffs
    
    with open("plane.txt", 'w') as f:
        f.write(f"{a} {b} {c}")

    return a, b, c

# Example usage
points = [
    [0.4982053474089887, 0.303364760244252, 0.1758829439032985],
    [0.7770088469076353, 0.3084154301038013, 0.18095787500837113],
    [0.5127871913464821, -0.2900115412808411, 0.17642811379761786],
    [0.7904385952296581, -0.2981682138012982, 0.1823904995329424]
]
a, b, c = fit_plane_least_squares(points)
print(f"Plane equation: z = {a}x + {b}y + {c}")
