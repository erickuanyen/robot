#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl_conversions/pcl_conversions.h>
#include <bits/stdc++.h>
#include <pcl/io/pcd_io.h>
#include <xmlrpcpp/XmlRpcValue.h> // catkin component
#include <boost/bind.hpp>
#include <pcl/filters/extract_indices.h>
#include <pcl/point_types_conversion.h>
#include <std_msgs/Int32MultiArray.h>
#include <std_msgs/Float32MultiArray.h>
std::ofstream fout;
int v1(0), v2(1);
int x, y, z, t;
std::vector<float> puck= {-1,-1,-1,-1};
float EucDist(pcl::PointXYZRGB p){
    return (ceil(100*sqrtf(p.x*p.x + p.y*p.y + p.z*p.z)/100));
}

// int find_nearest(int puck[][], pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud){
//     float minval = std::numeric_limits<float>::infinity();
//     int minball = 0;
//     for(int i=0; i<sizeof(puck)/sizeof(int)/3; i++){
//         pcl::PointXYZRGB p = cloud->points[puck[i][0]*cloud->width + puck[i][1]];
// 	 	if (minval>  EucDist(p)){
//             minval =  EucDist(p);
//             minball = i;
//         }
//     }
//     return minball;
// }
pcl::PointIndices::Ptr get_HSV_filter_inliers(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud,
    double H_Lower,double H_Higher,
    double S_Lower = 0.0, double S_Higher = 1.0, 
    double V_Lower = 0, double V_Higher = 1.0)
{
    pcl::PointCloud<pcl::PointXYZHSV>::Ptr cloud_HSV(new pcl::PointCloud<pcl::PointXYZHSV>);
    pcl::PointCloudXYZRGBtoXYZHSV(*cloud,*cloud_HSV);
    pcl::PointIndices::Ptr inliers (new pcl::PointIndices());
    // double d_V_Lower = V_Lower/double(255.0);
    // double d_V_Higher = V_Higher/double(255.0);
    for (size_t i = 0; i < cloud_HSV->points.size(); ++i)
    {   
        if(cloud_HSV->points[i].h > H_Lower && cloud_HSV->points[i].h < H_Higher 
        ){
            if(cloud_HSV->points[i].v > V_Lower && cloud_HSV->points[i].v < V_Higher){
                if(cloud_HSV->points[i].s > S_Lower && cloud_HSV->points[i].s < S_Higher)
                    inliers->indices.push_back(i);
            }
        }
    }
    return inliers;
}
void BallFilter(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud){
    pcl::PointIndices::Ptr inliers_r1 (new pcl::PointIndices());
    pcl::PointIndices::Ptr inliers_r2 (new pcl::PointIndices());
    pcl::PointIndices::Ptr inliers (new pcl::PointIndices());
    pcl::ExtractIndices<pcl::PointXYZRGB> eifilter(true);     

    //Global Distance Filter  
    // inliers = get_dist_filter_inliers(cloud,1.0);
    // eifilter.setInputCloud(cloud);
    // eifilter.setIndices(inliers);
    // eifilter.filter(*cloud);
    // inliers.reset();

    // Plant Region Filter
    // inliers = get_aruco_filter_inliers(cloud,-0.1,0.1,-0.1,0.1,0.0,plant_height*1.1);
    // eifilter.setInputCloud(cloud);
    // eifilter.setIndices(inliers);
    // eifilter.filter(*cloud);
    // inliers.reset();

    //HSV Filter
    inliers_r1 = get_HSV_filter_inliers(cloud,0,20,0.2,1.0,0.3,1.0);
    inliers_r2 = get_HSV_filter_inliers(cloud,340,359,0.2,1.0,0.3,1.0);
    for(auto ir1:inliers_r1->indices){
        inliers_r2->indices.push_back(ir1);
    }
    eifilter.setInputCloud(cloud);
    eifilter.setIndices(inliers_r2);
    eifilter.filter(*cloud); 

}

// pcl::visualization::PCLVisualizer::Ptr viewer (new pcl::visualization::PCLVisualizer ("Alignment Process Visulizer"));

void puck_pixel_callback(const std_msgs::Float32MultiArray::ConstPtr& msg)
{
    // Call the pixel_callback function and pass the pixel data as an argument
    puck = {msg->data[0], msg->data[1], msg->data[2], msg->data[3]};
    std::cout << puck[0] << puck[1] << puck[2] << puck[3] << endl;
    
}
void pointcloud_callback(const sensor_msgs::PointCloud2::ConstPtr ptr){
    ros::NodeHandle nh;

    std::ofstream out;
    // If you want to access the data in the pointcloud, you have to convert data type from "PointCloud2" to "pcl::PointCloud<pcl::PointXYZRGB>"
    //create PCL pointcloud
    std_msgs::Float32MultiArray::ConstPtr msg = ros::topic::waitForMessage<std_msgs::Float32MultiArray>("PuckPixel");
    puck = {msg->data[0], msg->data[1], msg->data[2], msg->data[3]};
    // std::cout << puck[0] << " " << puck[1] << " " << puck[2] << " " << puck[3] << endl;
    while(puck[0] == -1 && puck[1] == -1 && puck[2] == -1 && puck[3] == -1){
        continue;
    }
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_ball (new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::fromROSMsg(*ptr,*cloud);
    
    pcl::PointXYZRGB p = cloud->points[puck[1]*cloud->width + puck[0]];
    // std::cout << p.x << " " << p.y << " " << p.z << std::endl;
    fout <<  p.x << "\t" << p.y << "\t" << p.z <<"\t"<< puck[3] << "\t" << puck[0]<< "\t" <<puck[1]<< "\t" <<  std::endl;
	std::vector<float_t> cam_to_puck;
    cam_to_puck.push_back(p.x);
    cam_to_puck.push_back(p.y);
    cam_to_puck.push_back(p.z);
    cam_to_puck.push_back(puck[3]);
    // std::cout << cam_to_puck[0] << " " << cam_to_puck[1] << " " << cam_to_puck[2] << " " << cam_to_puck[3] << endl;
    
    ros::Publisher pub = nh.advertise<std_msgs::Float32MultiArray>("cam_to_puck", 10, true);
    // sleep(0.05);
    // Create a message object to publish
    std_msgs::Float32MultiArray cam_perspective;
    // cam_perspective.data[0] = cam_to_ball[0]; // Set the first element to the value of x
    // cam_perspective.data[1] = cam_to_ball[1]; // Set the second element to the value of y
    // cam_perspective.data[2] = cam_to_ball[2]; // Set the third element to the value of z
    cam_perspective.data = cam_to_puck;
    // std::cout << cam_perspective << endl;
    // cam_perspective.data.push_back(p.x);
    // cam_perspective.data.push_back(p.y);
    // cam_perspective.data.push_back(p.z);
// // Publish the message
    pub.publish(cam_perspective);

    //nh.setParam("cam_to_ball", cam_to_ball);
    //save pcd here
    // pcl::io::savePCDFileASCII(std::to_string(ptr->header.stamp.toNSec()) + "_basketball.pcd",*cloud);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr point_p (new pcl::PointCloud<pcl::PointXYZRGB>);
    point_p->points.push_back(p);
    pcl::copyPointCloud(*cloud,*cloud_ball);
    BallFilter(cloud_ball);

    // viewer->removeAllPointClouds();
    // viewer->addCoordinateSystem(0.1);
    // viewer->addPointCloud(cloud,"cloud",v1);
    // viewer->addPointCloud(point_p,"point_p");
    // viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,1,0.2,0.2,"point_p");
    // viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,8,"point_p");
    // viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,2,"cloud");

    // viewer->addPointCloud(cloud_ball,"cloud_ball",v2);
    // viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,2,"cloud_ball");

    // viewer->spinOnce(1000);
}   

int main (int argc, char* argv[]){
    ros::init(argc, argv, "pointcloud_node",ros::init_options::AnonymousName);
    ros::NodeHandle nh;
    int sampletime, totaltime;
    nh.getParam("sampletime", sampletime);
    nh.getParam("totaltime", totaltime);
    fout.open("read_pointcloud.txt");
    fout << "x_from_cam" << "\t" << "y_from_cam" << "\t" << "z_from_cam" << "time\t" << "image_x\t" << "image_y\t" << "time" << std::endl; 
    ros::Rate rate(100);
    // ros::Subscriber sub1 = nh.subscribe("PuckPixel", 10, puck_pixel_callback);
    ros::Subscriber sub2 = nh.subscribe<sensor_msgs::PointCloud2>("/camera/depth_registered/points",10,pointcloud_callback);
    // viewer->createViewPort(0.0,0.0,0.5,1.0,v1);
    // viewer->createViewPort(0.5,0.0,1.0,1.0,v2);
    // sensor_msgs::PointCloud2ConstPtr ptr = ros::topic::waitForMessage<sensor_msgs::PointCloud2>("/camera/depth_registered/points",ros::Duration(0.5));
    // if(ptr){
    //     std::cout << "Width = " << ptr->width << "\t Height = " << ptr->height << std::endl; 
    //     //If you want to access the data in the pointcloud, you have to convert data type from "PointCloud2" to "pcl::PointCloud<pcl::PointXYZRGB>"
    //     std::vector<int> puck;
    //     nh.getParam("puck", puck);
    //     //create PCL pointcloud
    //     while(puck[0] == -1 && puck[1] == -1 && puck[2] == -1){
    //         continue;
    //     }
    //     pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGB>);
    //     pcl::fromROSMsg(*ptr,*cloud);
    //     /*
    //     int nearest = 0;
    //     if (sizeof(puck)/sizeof(int)/3!=1){
    //         int nearest = find_nearest(puck, cloud);
    //     }
    //     */
    //     //locate the nearest ball pixel
	// 	pcl::PointXYZRGB p = cloud->points[puck[0]*cloud->width + puck[1]];
    //     std::cout << p.x << " " << p.y << " " << p.z << std::endl;
    //     std::vector<double> position;
    //     position.push_back(p.x);
    //     position.push_back(p.y);
    //     position.push_back(p.z);
	// 	nh.setParam("position", position);
    //     //save pcd here
    //     pcl::io::savePCDFileASCII(std::to_string(ptr->header.stamp.toNSec()) + "_basketball.pcd",*cloud);
    // }
    

    while(!ros::isShuttingDown()){
        //std::cout << puck[0] << puck[1] << puck[2] << puck[3] << endl;
        ros::spinOnce();
        rate.sleep();
    }
    fout.close();
    
    return 0;
}
